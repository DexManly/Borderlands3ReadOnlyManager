Version: 0.0.2.0 (beta)
Author : DexManly (dex_manly on twitch)

== Warning! ==
This software is provided as is! I shall not be held responsible for any loss of data that may ensue from the use of this application!

Please make frequent backups! Check and double check that Read-Only is properly applied to your saves before doing anything in game!


If you find an issue, please note it in the issues tab of https://github.com/DexManly/Borderlands3ReadOnlyManager or feel free to contribute to the repo.

Release notes for 0.0.2.0
=========================
- Added meta data reading from .sav files.
- Sorting should be saved between sessions now.